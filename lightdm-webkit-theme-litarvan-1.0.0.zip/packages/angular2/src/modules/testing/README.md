# angular2/modules/testing

## Directory structure

The new `testing` sub-package for Angular Dart.

It is developed as-if it is a standalone package, but built and shipped as part
of the `angular2` package. When pub supports sub-packages, this folder can
simply be moved.

## Usage

TODO: Explain the API usage once stable.
